# BangunDatar
Program Menghitung Luas dan Keliling Bangun Datar dengan Java OOP Berbasis CLI.

# Fitur Dalam Program Ini
Menghitung Luas dan Keliling dari Bangun Datar:
1. Persegi
2. Persegi Panjang
3. Segitiga Siku-siku
4. Jajar Genjang
5. Trapesium
6. Layang-layang
7. Belah Ketupat
8. Lingkaran

# Cara Menjalankan Program
Silahkan buka IDE Intellij Idea kemudian pilih file > open > terus pilih folder project yang ingin dibuka (dalam project ini BangunDatar).

# Versi Java
Versi Java yang direkomendasikan untuk menjalankan program ini adalah versi 10 ke atas untuk menghindari kesalahan.
