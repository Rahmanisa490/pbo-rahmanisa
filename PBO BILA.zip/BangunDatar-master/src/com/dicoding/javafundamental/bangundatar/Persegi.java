package com.dicoding.javafundamental.bangundatar;

public class Persegi implements BangunDatar {

    Persegi() {}

    @Override
    public double luas(double s1, double s2) {
        return 0;
    }

    @Override
    public double keliling(double s1, double s2) {
        return 0;
    }

    public double luas(double s) {
        return (s * s);
    }

    public double keliling(double s) {
        return (4 * s);
    }
}
