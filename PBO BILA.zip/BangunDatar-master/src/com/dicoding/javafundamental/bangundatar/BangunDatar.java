package com.dicoding.javafundamental.bangundatar;

public interface BangunDatar {

    double luas(double s1, double s2);
    double keliling(double s1, double s2);
}
